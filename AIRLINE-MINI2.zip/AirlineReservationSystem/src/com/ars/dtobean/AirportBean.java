package com.ars.dtobean;


public class AirportBean {
private String Airport_Name;
private String Abbreviation;
private String city;
private String state;
private int zipcode;
public String getAirport_Name() {
	return Airport_Name;
}
public void setAirport_Name(String airport_Name) {
	Airport_Name = airport_Name;
}
public String getAbbreviation() {
	return Abbreviation;
}
public void setAbbreviation(String abbreviation) {
	Abbreviation = abbreviation;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public int getZipcode() {
	return zipcode;
}
public void setZipcode(int zipcode) {
	this.zipcode = zipcode;
}
public AirportBean(String airport_Name, String abbreviation, String city, String state, int zipcode) {
	super();
	Airport_Name = airport_Name;
	Abbreviation = abbreviation;
	this.city = city;
	this.state = state;
	this.zipcode = zipcode;
}

}
