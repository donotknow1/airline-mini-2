package com.ars.dtobean;

public class FlightBean {
	
	private int flightNo;
	private String airline;
	private String depCity;
	private String arrCity;
	private String depdate;
	private String arrDate;
	private String depTime;
	private String arrTime;
	private int firstSeats;
	private int firstFair;
	private int bussSeats;
	private int bussFair;
	
	public int getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDepCity() {
		return depCity;
	}
	public void setDepCity(String depCity) {
		this.depCity = depCity;
	}
	public String getArrCity() {
		return arrCity;
	}
	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}
	public String getDepdate() {
		return depdate;
	}
	public void setDepdate(String depdate) {
		this.depdate = depdate;
	}
	public String getArrDate() {
		return arrDate;
	}
	public void setArrDate(String arrDate) {
		this.arrDate = arrDate;
	}
	public String getDepTime() {
		return depTime;
	}
	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}
	public String getArrTime() {
		return arrTime;
	}
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	public int getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}
	public int getFirstFair() {
		return firstFair;
	}
	public void setFirstFair(int firstFair) {
		this.firstFair = firstFair;
	}
	public int getBussSeats() {
		return bussSeats;
	}
	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}
	public int getBussFair() {
		return bussFair;
	}
	public void setBussFair(int bussFair) {
		this.bussFair = bussFair;
	}
	
	public FlightBean(int flightNo, String airline, String depCity, String arrCity, String depdate, String arrDate,
			String depTime, String arrTime, int firstSeats, int firstFair, int bussSeats, int bussFair) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.depCity = depCity;
		this.arrCity = arrCity;
		this.depdate = depdate;
		this.arrDate = arrDate;
		this.depTime = depTime;
		this.arrTime = arrTime;
		this.firstSeats = firstSeats;
		this.firstFair = firstFair;
		this.bussSeats = bussSeats;
		this.bussFair = bussFair;
	}
	
	@Override
	public String toString() {
		return "FlightBean [flightNo=" + flightNo + ", airline=" + airline + ", depCity=" + depCity + ", arrCity="
				+ arrCity + ", depdate=" + depdate + ", arrDate=" + arrDate + ", depTime=" + depTime + ", arrTime="
				+ arrTime + ", firstSeats=" + firstSeats + ", firstFair=" + firstFair + ", bussSeats=" + bussSeats
				+ ", bussFair=" + bussFair + "]";
	}
	
	public FlightBean(String depCity, String arrCity, int firstFair, int bussFair) {
		super();
		this.depCity = depCity;
		this.arrCity = arrCity;
		this.firstFair = firstFair;
		this.bussFair = bussFair;
	}
	
	
	
	
	

}
