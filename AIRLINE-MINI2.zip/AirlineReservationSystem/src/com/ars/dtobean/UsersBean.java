package com.ars.dtobean;

public class UsersBean {
private String username;
private String password;
private String role;

private int mobile_number;
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getRole() {
	return role;
}
public void setRole1(String role) {
	this.role = role;
}
public int getMobile_number() {
	return mobile_number;
}
public void setMobile_number(int mobile_number) {
	this.mobile_number = mobile_number;
}


public UsersBean(String username, String password,String role) {
	super();
	this.username = username;
	this.password = password;
	this.role=role;
}
public UsersBean() {
	// TODO Auto-generated constructor stub
}



}
