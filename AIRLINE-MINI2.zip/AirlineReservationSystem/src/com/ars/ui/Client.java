package com.ars.ui;

import java.util.List;
import java.util.Random;
import java.sql.SQLException;
import java.util.Scanner;

import com.ars.dtobean.BookingBean;
import com.ars.dtobean.FlightBean;
import com.ars.dtobean.UsersBean;
import com.ars.exception.AirlineException;
import com.ars.service.ARSService;
import com.ars.service.IARSService;

public class Client {

	static Scanner scan=null; 
	static IARSService iars=null;
	static String role=null;
	static UsersBean airbean=new UsersBean();
	static BookingBean book=null;
	
	public static void main(String[] args) throws SQLException, AirlineException{
		scan=new Scanner(System.in);
		
		System.out.println("-------------WELCOME--------------------");
		System.out.println("1.GET FLIGHT INFORMATION");
		System.out.println("2.AIRLINE EXECUTIVE LOGIN");
		System.out.println("3.ADMINISTRATION LOGIN");
		System.out.println("4.EXIT");
		
		System.out.println("Choose your option");
		int option=scan.nextInt();
		
		switch(option) {
		
		case 1:
			
			viewFlightDetails();
			FlightBean fbean=null;
			System.out.println("If you want to continue with booking");
			do {
			System.out.println("Please Enter Valid flight number:");
			int fno=scan.nextInt();
			try {
				fbean=validateFlight(fno);
	        }
			catch(AirlineException e) {
	        	System.out.println(e.getMessage());
	        }
	        }while(fbean==null);
		/*	List<FlightBean> flightList=null;
			
			try {
				flightList=getFlightDetails();
			}
			catch(AirlineException e) {
				System.out.println(e.getMessage());
			}
			
			for(FlightBean fb:flightList) {
				System.out.println(fb);
			}
				System.out.println("If you want to continue with booking");
				System.out.println("Please Enter flight number:");
				int fno=scan.nextInt();
				FlightBean fbean=null;
				try {
				fbean=validateFlight(fno);
            }catch(AirlineException e) {
            	System.out.println(e.getMessage());
            }         */
				System.out.println("1.Confirm booking");
				System.out.println("2.Exit");
				int opt=scan.nextInt();
				Random rand = new Random();
				int n = rand.nextInt(50) + 1;
				String classType=null;
				int totalF = 0;
				switch(opt) {
				case 1:
					System.out.println("Enter your email id");
					String email=scan.next();
					System.out.println("Enter number of passengers");
					int pass=scan.nextInt();
					System.out.println("1.First class");
					System.out.println("2.Business class");
					int Type=scan.nextInt();
					if(Type==1) {
					    classType="firstclass";
						int firstFare=fbean.getFirstFair();
						totalF=pass*firstFare;					
						}
					else if(Type==2) {
						classType="bussclass";
						int bussFare=fbean.getBussFair();
						totalF=pass*bussFare;
					}
					else  {
						System.out.println("please enter class type correctly...");
					}
					//seat number is balance
					System.out.println("Please Enter Credit Card Number");
					String creditCard=scan.next();
				

					book=new BookingBean(email, pass, classType, totalF,n, creditCard, fbean.getDepCity(), fbean.getArrCity());
				}
			
				int val=0;
				try {
					val=bookFlight(book);
				}catch(AirlineException e) {
					System.out.println(e.getMessage());
				}
			
				System.out.println(val+" booking is confirmed");       
			
			
			

			
			break;
			
		case 2:
			System.out.println("ENTER YOUR USERNAME");
			String username=scan.next();
			System.out.println("ENTER YOUR PASSWORD");
			String password=scan.next();
			System.out.println("role: 1.Executive 2.Admin");
			String role=scan.next();
			
			if(role.equals("executive")) {
				UsersBean airbean=new UsersBean(username, password,role);
				

			}
			if(role.equals("admin")) {
				UsersBean airbean=new UsersBean(username, password,role);
				System.out.println("1.view flight schedule");
				System.out.println("2.update flight schedule");
				System.out.println("3.Delete flight schedule");
				System.out.println("4.Insert Flight details");
			}
		
	
			System.out.println("Enter your option");
			int choose=scan.nextInt();
			switch(choose) {
			
			case 1:
				viewFlightDetails();
			case 2:
				//update flight schedule updateFlightDetails();   
			case 3:
				//delete flight schedule  deleteFlightDetails();
			case 4:
				//insert flight Details  insertFlightDetails();
			
			}
			
			
		
				
		
		
		}
		
		
	}
		
	
	public static List<FlightBean> getFlightDetails() throws AirlineException
	{
		iars=new ARSService();
		return iars.getFlightDetails();
	}
		
	

	public static UsersBean adminDetails(UsersBean airbean) throws SQLException {
		
		return iars.adminDetailsServ(airbean);
		
	}
	
	public static FlightBean validateFlight(int fno) throws AirlineException {
		
		iars=new ARSService();
		return iars.viewAllFlight(fno);
	}
	
	
	public static int bookFlight(BookingBean book) throws AirlineException {
		
		iars=new ARSService();
		
		return iars.bookFlight(book);
	}
	
	
	public static void viewFlightDetails() {
		
		List<FlightBean> flightList=null;
		
		try {
			flightList=getFlightDetails();
		}
		catch(AirlineException e) {
			System.out.println(e.getMessage());
		}
		
		for(FlightBean fb:flightList) {
			System.out.println(fb);
		}
			
		
	}
	
}
