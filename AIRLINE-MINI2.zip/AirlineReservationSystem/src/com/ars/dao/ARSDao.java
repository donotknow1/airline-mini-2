package com.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ars.dtobean.BookingBean;
import com.ars.dtobean.FlightBean;
import com.ars.dtobean.UsersBean;
import com.ars.exception.AirlineException;
import com.ars.util.DbUtil;

public class ARSDao implements IARSDao {

		Connection conn=null;
	
	@Override
	public UsersBean adminDetailsDao(UsersBean airbean) throws SQLException {
		
		conn=DbUtil.getConnection();
		
		PreparedStatement retrieve=conn.prepareStatement(null);
	
		
		return null;
	}

	@Override
	public List<FlightBean> getFlightDetails() throws AirlineException {
		
		conn=DbUtil.getConnection();
		List<FlightBean> flight=null;
		
		try {
			Statement getFlight=conn.createStatement();
			ResultSet rs1=getFlight.executeQuery(IQueryMapper.SELECT_QRY_FLIGHTINFO);
			//PreparedStatement getFlight=conn.prepareStatement(IQueryMapper.SELECT_QRY_FLIGHTINFO);
			flight=new ArrayList<>();
			FlightBean f=null;
			while(rs1.next()) {
				f=new FlightBean(rs1.getInt(1), rs1.getString(2), rs1.getString(3), rs1.getString(4), rs1.getString(5), rs1.getString(6), rs1.getString(7),rs1.getString(8), rs1.getInt(9), rs1.getInt(10),rs1.getInt(11), rs1.getInt(12)); 
			    flight.add(f);
			}
			
		} catch (SQLException e) {
			
			throw new AirlineException("Data can't be retrieved");
		}
		
		return flight;
	}

	@Override
	public FlightBean viewAllFlight(int fno) throws AirlineException {
	
		conn=DbUtil.getConnection();
		FlightBean f2=null;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.SELECT_QRY_FLIGHTID);
			pst.setInt(1, fno);
			ResultSet rs2=pst.executeQuery();
		/*	if(rs2!=null) {
				System.out.println("Please enter valid flight id");
			}                                                                 */
			while(rs2.next()) {
				f2=new FlightBean(rs2.getString(1),rs2.getString(2),rs2.getInt(3),rs2.getInt(4));
			}
			} catch (SQLException e) {
			throw new AirlineException(e.getMessage());
		}
		
		return f2;
	     
		
	}

	@Override
	public int bookFlight(BookingBean book) throws AirlineException {
		
		conn=DbUtil.getConnection();
		BookingBean b=null;
		int status=0;
		try {
			PreparedStatement bpst=conn.prepareStatement(IQueryMapper.INSERT_QRY_BOOKING_INFO);
			bpst.setString(1, book.getCustomerMail());
			bpst.setInt(2,book.getPassengers());
			bpst.setString(3,book.getClassType());
			bpst.setInt(4,book.getTotalFare());
			bpst.setString(5,book.getCreditCardNo());
			bpst.setString(6,book.getSrcCity());
			bpst.setString(7,book.getDestCity());
			status=bpst.executeUpdate();
		}catch(SQLException e) {
			throw new AirlineException("can't be inserted"+e.getMessage());
		}
		
		
		return status;
	}

	
	
	
	
}
