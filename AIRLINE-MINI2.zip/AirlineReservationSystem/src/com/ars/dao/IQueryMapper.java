package com.ars.dao;

public interface IQueryMapper {

static String SELECT_QRY_FLIGHTINFO="SELECT * FROM FLIGHT_INFORMATION";
static String SELECT_QRY_FLIGHTID="SELECT DEP_CITY,ARR_CITY,FIRSTSEATFARE,BUSSSEATSFARE FROM FLIGHT_INFORMATION WHERE FLIGHTNO=?";
static String INSERT_QRY_BOOKING_INFO="INSERT INTO BOOKING_INFO VALUES(booking_info_seq.NEXTVAL,?,?,?,?,seat_seq.NEXTVAL,?,?,?)";
static String INSERT_QRY_FLIGHT_INFO="INSERT INTO FLIGHT_INFORMATION VALUES(3124,'airasia','chennai','hyderabad',sysdate,sysdate,sysdate,sysdate,50,1500,30,3500)";

	
}
