package com.ars.dao;

import java.sql.SQLException;
import java.util.List;

import com.ars.dtobean.BookingBean;
import com.ars.dtobean.FlightBean;
import com.ars.dtobean.UsersBean;
import com.ars.exception.AirlineException;

public interface IARSDao {

	UsersBean adminDetailsDao(UsersBean airbean) throws SQLException;

	List<FlightBean> getFlightDetails() throws AirlineException;

	FlightBean viewAllFlight(int fno) throws AirlineException;

	int bookFlight(BookingBean book) throws AirlineException;

}
